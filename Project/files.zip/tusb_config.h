/*
 * tusb_config.h — Place in ESB_Receiver sketch folder
 *
 * Overrides Adafruit's default TinyUSB config.
 * Disables CDC (no Serial) since Xbox 360 descriptors replace it.
 */

#ifndef TUSB_CONFIG_H
#define TUSB_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

#define CFG_TUSB_MCU          OPT_MCU_NRF5X
#define CFG_TUSB_OS           OPT_OS_FREERTOS

// Device mode only
#define CFG_TUD_ENABLED       1
#define CFG_TUH_ENABLED       0

// Disable all standard classes — we use custom XInput driver
#define CFG_TUD_CDC           0
#define CFG_TUD_MSC           0
#define CFG_TUD_HID           0
#define CFG_TUD_MIDI          0
#define CFG_TUD_VENDOR        0

// Endpoint 0 size
#define CFG_TUD_ENDPOINT0_SIZE 64

// Debug level (0=off, 1=errors, 2=verbose)
#ifndef CFG_TUSB_DEBUG
#define CFG_TUSB_DEBUG        0
#endif

#ifdef __cplusplus
}
#endif

#endif
