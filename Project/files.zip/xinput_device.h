/*
 * xinput_device.h — Xbox 360 XInput USB Device for NRF52840
 *
 * Overrides Adafruit's TinyUSB descriptors to present as Xbox 360 Controller.
 * Windows loads xusb22.sys automatically (VID=045E, PID=028E).
 *
 * Place this file in the same folder as your .ino sketch.
 */

#ifndef XINPUT_DEVICE_H
#define XINPUT_DEVICE_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// Xbox 360 input report — 20 bytes
typedef struct __attribute__((packed)) {
    uint8_t  report_id;      // Always 0x00
    uint8_t  report_size;    // Always 0x14 (20)
    uint16_t wButtons;       // XInput button bitfield
    uint8_t  bLeftTrigger;   // 0-255
    uint8_t  bRightTrigger;  // 0-255
    int16_t  sThumbLX;       // -32768 to 32767
    int16_t  sThumbLY;
    int16_t  sThumbRX;
    int16_t  sThumbRY;
    uint8_t  reserved[6];    // Padding to 20 bytes
} xinput_report_t;

// Send an XInput report to the PC. Returns true on success.
bool xinputd_send_report(const xinput_report_t *report);

// Check if USB is configured and ready to send.
bool xinputd_ready(void);

#ifdef __cplusplus
}
#endif

#endif
