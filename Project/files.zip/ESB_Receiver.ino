/*
 * ESB_Receiver.ino — Xbox 360 XInput Edition
 *
 * Based on your working HID receiver code.
 * Radio code: UNCHANGED (bare-metal NRF_RADIO registers)
 * USB: Changed from Adafruit_USBD_HID to Xbox 360 XInput
 *
 * Windows sees: "Xbox 360 Controller" → xusb22.sys loaded automatically
 * Works with every XInput game, Steam, Game Pass, joy.cpl
 *
 * NOTE: CDC Serial is NOT available (Xbox 360 descriptors replace it).
 *       Debug output goes to UART on P0.06 (TX) at 115200 baud.
 *       Connect USB-TTL adapter RX to P0.06, GND to GND.
 *       Or just watch the LED for status.
 *
 * LED behavior:
 *   5 fast blinks  = firmware alive
 *   Slow blink     = waiting for radio packets
 *   Toggle on each = receiving packets
 */

#include "Adafruit_TinyUSB.h"   // Needed for TinyUSB types
#include "nrf_sdm.h"

// XInput device driver (xinput_device.c in same folder)
extern "C" {
#include "xinput_device.h"
}

// ============================================================
//  Radio config (UNCHANGED from your working code)
// ============================================================
#define RADIO_CHANNEL     2
#define PAYLOAD_LEN       14
#define RADIO_BASE_ADDR   0xE7E7E7E7UL
#define RADIO_PREFIX_BYTE 0xE7

#define LED_PIN LED_BUILTIN

// ---- Radio buffers ----
static uint8_t radio_pkt[PAYLOAD_LEN] __attribute__((aligned(4)));
static uint8_t local_pkt[PAYLOAD_LEN];

static uint32_t rx_count = 0;
static uint32_t crc_errors = 0;
static uint32_t last_status_ms = 0;

// ---- XInput report ----
static xinput_report_t xreport;

// ---- Debug UART (optional — connect USB-TTL adapter to P0.06) ----
#define DEBUG_TX_PIN  6   // P0.06
#define DEBUG_BAUD    115200

static void debug_print(const char *msg) {
    while (*msg) {
        NRF_UARTE0->EVENTS_ENDTX = 0;
        static uint8_t tx_byte;
        tx_byte = *msg++;
        NRF_UARTE0->TXD.PTR = (uint32_t)&tx_byte;
        NRF_UARTE0->TXD.MAXCNT = 1;
        NRF_UARTE0->TASKS_STARTTX = 1;
        while (!NRF_UARTE0->EVENTS_ENDTX);
    }
}

static void debug_init(void) {
    // Configure P0.06 as UART TX
    NRF_GPIO->DIRSET = (1UL << DEBUG_TX_PIN);
    NRF_GPIO->OUTSET = (1UL << DEBUG_TX_PIN);

    NRF_UARTE0->PSEL.TXD = DEBUG_TX_PIN;
    NRF_UARTE0->PSEL.RXD = 0xFFFFFFFF; // Disconnected
    NRF_UARTE0->BAUDRATE = 0x01D7E000;  // 115200
    NRF_UARTE0->CONFIG = 0;             // No parity, 1 stop bit
    NRF_UARTE0->ENABLE = 8;             // Enable
}

// ============================================================
//  Radio (UNCHANGED from your working code)
// ============================================================

void radio_init() {
    NVIC_DisableIRQ(RADIO_IRQn);
    NVIC_ClearPendingIRQ(RADIO_IRQn);

    NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;
    NRF_CLOCK->TASKS_HFCLKSTART = 1;
    while (!NRF_CLOCK->EVENTS_HFCLKSTARTED);

    NRF_RADIO->TASKS_DISABLE = 1;
    while (NRF_RADIO->STATE != 0);

    NRF_RADIO->POWER = 1;
    NRF_RADIO->TXPOWER  = 0;
    NRF_RADIO->FREQUENCY = RADIO_CHANNEL;
    NRF_RADIO->MODE      = RADIO_MODE_MODE_Nrf_2Mbit;

    NRF_RADIO->PCNF0 = 0;
    NRF_RADIO->PCNF1 = (PAYLOAD_LEN << RADIO_PCNF1_STATLEN_Pos) |
                        (PAYLOAD_LEN << RADIO_PCNF1_MAXLEN_Pos)  |
                        (4 << RADIO_PCNF1_BALEN_Pos);

    NRF_RADIO->BASE0      = RADIO_BASE_ADDR;
    NRF_RADIO->PREFIX0    = RADIO_PREFIX_BYTE;
    NRF_RADIO->RXADDRESSES = 1;

    NRF_RADIO->CRCCNF  = RADIO_CRCCNF_LEN_Two;
    NRF_RADIO->CRCPOLY = 0x11021;
    NRF_RADIO->CRCINIT = 0xFFFF;

    NRF_RADIO->PACKETPTR = (uint32_t)radio_pkt;
    NRF_RADIO->SHORTS = RADIO_SHORTS_END_START_Msk;
}

void radio_start_rx() {
    NRF_RADIO->EVENTS_READY = 0;
    NRF_RADIO->EVENTS_END   = 0;
    NRF_RADIO->TASKS_RXEN = 1;
    while (!NRF_RADIO->EVENTS_READY);
    NRF_RADIO->EVENTS_END = 0;
    NRF_RADIO->TASKS_START = 1;
}

// ============================================================
//  Setup
// ============================================================

void setup() {
    pinMode(LED_PIN, OUTPUT);

    // 5 fast blinks = alive
    for (int i = 0; i < 5; i++) {
        digitalWrite(LED_PIN, HIGH); delay(100);
        digitalWrite(LED_PIN, LOW);  delay(100);
    }

    // DO NOT call Serial.begin() — CDC is replaced by Xbox 360 descriptors
    // Use debug UART instead (optional)
    debug_init();
    debug_print("\r\n== ESB Receiver — Xbox 360 XInput ==\r\n");

    // Disable SoftDevice for direct RADIO access
    sd_softdevice_disable();

    // Init radio (your exact working code)
    radio_init();
    radio_start_rx();

    debug_print("Radio: 2Mbps, Ch2. Listening...\r\n");

    // Init XInput report to neutral
    memset(&xreport, 0, sizeof(xreport));
    xreport.report_id   = 0x00;
    xreport.report_size = 0x14;

    // Wait for USB mount
    while (!tud_mounted()) delay(1);

    debug_print("USB mounted as Xbox 360 Controller!\r\n");
    digitalWrite(LED_PIN, LOW);
}

// ============================================================
//  Loop
// ============================================================

void loop() {
    // Keep TinyUSB running
    // (Adafruit core calls tud_task() automatically, but belt-and-suspenders)
    tud_task();

    // Handle unexpected radio disable
    if (NRF_RADIO->EVENTS_DISABLED) {
        NRF_RADIO->EVENTS_DISABLED = 0;
        if (NRF_RADIO->STATE == 0) {
            radio_start_rx();
        }
    }

    // Check for received radio packet
    if (NRF_RADIO->EVENTS_END) {
        NRF_RADIO->EVENTS_END = 0;

        memcpy(local_pkt, radio_pkt, PAYLOAD_LEN);
        bool crc_ok = (NRF_RADIO->CRCSTATUS == 1);

        if (crc_ok) {
            rx_count++;
            digitalToggle(LED_PIN);

            // Decode radio payload (same layout as XInput — zero remapping!)
            uint16_t buttons = local_pkt[0] | (local_pkt[1] << 8);
            int16_t  lx = (int16_t)(local_pkt[2]  | (local_pkt[3]  << 8));
            int16_t  ly = (int16_t)(local_pkt[4]  | (local_pkt[5]  << 8));
            int16_t  rx = (int16_t)(local_pkt[6]  | (local_pkt[7]  << 8));
            int16_t  ry = (int16_t)(local_pkt[8]  | (local_pkt[9]  << 8));
            uint8_t  lt = local_pkt[10];
            uint8_t  rt = local_pkt[11];

            // Build XInput report — direct copy, no remapping
            xreport.wButtons      = buttons;
            xreport.bLeftTrigger  = lt;
            xreport.bRightTrigger = rt;
            xreport.sThumbLX      = lx;
            xreport.sThumbLY      = ly;
            xreport.sThumbRX      = rx;
            xreport.sThumbRY      = ry;

            // Send to PC as Xbox 360 controller
            if (xinputd_ready()) {
                xinputd_send_report(&xreport);
            }
        } else {
            crc_errors++;
        }
    }

    // Status blink (if no packets, slow blink)
    static uint32_t last_blink = 0;
    static bool blink_state = false;
    uint32_t now = millis();
    if (rx_count == 0 && (now - last_blink > 500)) {
        last_blink = now;
        blink_state = !blink_state;
        digitalWrite(LED_PIN, blink_state);
    }
}
