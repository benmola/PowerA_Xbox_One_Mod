/*
 * xinput_device.c — Xbox 360 XInput USB Device Driver
 *
 * This file overrides the Adafruit TinyUSB descriptor callbacks.
 * It works because Arduino's linker resolves sketch .o files before
 * library .a archives, so our symbols take priority.
 *
 * Provides:
 *   - Xbox 360 device descriptor (VID=045E, PID=028E)
 *   - Xbox 360 configuration descriptor with vendor interface + 17-byte magic
 *   - String descriptors
 *   - Custom TinyUSB class driver for XInput endpoint management
 *   - xinputd_send_report() and xinputd_ready() public API
 *
 * Place this file in the same folder as your .ino sketch.
 */

#include <string.h>
#include "tusb.h"
#include "device/usbd.h"
#include "device/usbd_pvt.h"
#include "xinput_device.h"

// ============================================================
//  Internal state
// ============================================================
static struct {
    uint8_t  ep_in;
    uint8_t  ep_out;
    uint8_t  itf_num;
    bool     mounted;
    uint8_t  out_buf[32];
} _xd;

// ============================================================
//  USB Descriptors
// ============================================================

// Device Descriptor — Xbox 360 Controller
static uint8_t const desc_device[] = {
    18,                 // bLength
    TUSB_DESC_DEVICE,   // bDescriptorType
    0x00, 0x02,         // bcdUSB = 2.00
    0xFF,               // bDeviceClass = Vendor
    0xFF,               // bDeviceSubClass
    0xFF,               // bDeviceProtocol
    64,                 // bMaxPacketSize0
    0x5E, 0x04,         // idVendor  = 0x045E (Microsoft)
    0x8E, 0x02,         // idProduct = 0x028E (Xbox 360 Controller)
    0x14, 0x01,         // bcdDevice = 1.14
    1,                  // iManufacturer
    2,                  // iProduct
    3,                  // iSerialNumber
    1,                  // bNumConfigurations
};

// Configuration Descriptor
// Interface 0: XInput gamepad (0xFF/0x5D/0x01) + 17-byte vendor + 2 endpoints
// Interfaces 1-3: stubs (headset, unknown, security) — required by Windows
#define CONFIG_TOTAL_LEN  (9 + (9+17+7+7) + 9 + 9 + 9)

static uint8_t const desc_config[] = {
    // ---- Configuration (9) ----
    9, TUSB_DESC_CONFIGURATION,
    CONFIG_TOTAL_LEN & 0xFF, (CONFIG_TOTAL_LEN >> 8) & 0xFF,
    4,          // bNumInterfaces
    1,          // bConfigurationValue
    0,          // iConfiguration
    0x80,       // bmAttributes (bus powered)
    250,        // bMaxPower = 500mA

    // ---- Interface 0: XInput Gamepad (9) ----
    9, TUSB_DESC_INTERFACE,
    0,          // bInterfaceNumber
    0,          // bAlternateSetting
    2,          // bNumEndpoints
    0xFF,       // bInterfaceClass = Vendor
    0x5D,       // bInterfaceSubClass = XInput
    0x01,       // bInterfaceProtocol = Gamepad
    0,          // iInterface

    // ---- Vendor descriptor — Xbox 360 magic (17) ----
    0x11, 0x21, 0x00, 0x01, 0x01, 0x25, 0x81, 0x14,
    0x03, 0x00, 0x03, 0x00, 0x03, 0x00, 0x03, 0x00,
    0x03,

    // ---- IN Endpoint 0x81 (7) ----
    7, TUSB_DESC_ENDPOINT,
    0x81,       // bEndpointAddress = IN 1
    0x03,       // bmAttributes = Interrupt
    0x20, 0x00, // wMaxPacketSize = 32
    4,          // bInterval = 4ms

    // ---- OUT Endpoint 0x02 (7) ----
    7, TUSB_DESC_ENDPOINT,
    0x02,       // bEndpointAddress = OUT 2
    0x03,       // bmAttributes = Interrupt
    0x20, 0x00, // wMaxPacketSize = 32
    8,          // bInterval = 8ms

    // ---- Interface 1: Headset stub (9) ----
    9, TUSB_DESC_INTERFACE, 1, 0, 0, 0xFF, 0x5D, 0x03, 0,

    // ---- Interface 2: Unknown stub (9) ----
    9, TUSB_DESC_INTERFACE, 2, 0, 0, 0xFF, 0x5D, 0x02, 0,

    // ---- Interface 3: Security stub (9) ----
    9, TUSB_DESC_INTERFACE, 3, 0, 0, 0xFF, 0xFD, 0x13, 0,
};

// ---- String Descriptors ----

// Helper: convert ASCII string to USB string descriptor in-place
static uint16_t desc_str_buf[32+1];

static uint16_t const *make_str_desc(const char *str) {
    uint8_t len = 0;
    while (str[len] && len < 31) {
        desc_str_buf[1 + len] = str[len];
        len++;
    }
    desc_str_buf[0] = (uint16_t)((TUSB_DESC_STRING << 8) | (2 * len + 2));
    return desc_str_buf;
}

// ============================================================
//  TinyUSB Descriptor Callbacks (override Adafruit's)
// ============================================================

uint8_t const *tud_descriptor_device_cb(void) {
    return desc_device;
}

uint8_t const *tud_descriptor_configuration_cb(uint8_t index) {
    (void)index;
    return desc_config;
}

uint16_t const *tud_descriptor_string_cb(uint8_t index, uint16_t langid) {
    (void)langid;
    switch (index) {
        case 0: {
            static uint16_t const lang[] = { (uint16_t)((TUSB_DESC_STRING << 8) | 4), 0x0409 };
            return lang;
        }
        case 1: return make_str_desc("Microsoft");
        case 2: return make_str_desc("Controller");
        case 3: return make_str_desc("ESB52840");
        default: return NULL;
    }
}

// ============================================================
//  TinyUSB Class Driver
// ============================================================

static void xd_init(void) {
    memset(&_xd, 0, sizeof(_xd));
}

static void xd_reset(uint8_t rhport) {
    (void)rhport;
    memset(&_xd, 0, sizeof(_xd));
}

static uint16_t xd_open(uint8_t rhport, tusb_desc_interface_t const *itf, uint16_t max_len) {
    // Only claim our gamepad interface (0xFF/0x5D/0x01)
    if (itf->bInterfaceClass != 0xFF ||
        itf->bInterfaceSubClass != 0x5D ||
        itf->bInterfaceProtocol != 0x01) {
        return 0;
    }

    uint16_t drv_len = 0;
    uint8_t const *p = (uint8_t const *)itf;

    // Skip interface descriptor
    _xd.itf_num = itf->bInterfaceNumber;
    drv_len += tu_desc_len(p);
    p += tu_desc_len(p);

    // Skip vendor descriptor (type 0x21)
    if (drv_len < max_len && tu_desc_type(p) == 0x21) {
        drv_len += tu_desc_len(p);
        p += tu_desc_len(p);
    }

    // Open endpoints
    for (int i = 0; i < 2 && drv_len < max_len; i++) {
        if (tu_desc_type(p) != TUSB_DESC_ENDPOINT) break;
        tusb_desc_endpoint_t const *ep = (tusb_desc_endpoint_t const *)p;

        TU_ASSERT(usbd_edpt_open(rhport, ep), 0);

        if (tu_edpt_dir(ep->bEndpointAddress) == TUSB_DIR_IN) {
            _xd.ep_in = ep->bEndpointAddress;
        } else {
            _xd.ep_out = ep->bEndpointAddress;
            // Start receiving OUT data (rumble — ignored)
            usbd_edpt_xfer(rhport, _xd.ep_out, _xd.out_buf, sizeof(_xd.out_buf));
        }

        drv_len += tu_desc_len(p);
        p += tu_desc_len(p);
    }

    _xd.mounted = true;
    return drv_len;
}

static bool xd_control_xfer_cb(uint8_t rhport, uint8_t stage, tusb_control_request_t const *request) {
    (void)rhport; (void)stage; (void)request;
    return true;
}

static bool xd_xfer_cb(uint8_t rhport, uint8_t ep_addr, xfer_result_t result, uint32_t xferred_bytes) {
    (void)result; (void)xferred_bytes;
    if (ep_addr == _xd.ep_out) {
        // Rumble received — ignore, re-queue
        usbd_edpt_xfer(rhport, _xd.ep_out, _xd.out_buf, sizeof(_xd.out_buf));
    }
    return true;
}

// Class driver struct
static usbd_class_driver_t const _xd_driver = {
#if CFG_TUSB_DEBUG >= 2
    .name = "XINPUT",
#endif
    .init            = xd_init,
    .reset           = xd_reset,
    .open            = xd_open,
    .control_xfer_cb = xd_control_xfer_cb,
    .xfer_cb         = xd_xfer_cb,
    .sof             = NULL,
};

// Register with TinyUSB
usbd_class_driver_t const *usbd_app_driver_get_cb(uint8_t *driver_count) {
    *driver_count = 1;
    return &_xd_driver;
}

// ============================================================
//  Public API
// ============================================================

bool xinputd_ready(void) {
    return _xd.mounted && _xd.ep_in != 0;
}

bool xinputd_send_report(const xinput_report_t *report) {
    if (!xinputd_ready()) return false;
    if (usbd_edpt_busy(0, _xd.ep_in)) return false;
    return usbd_edpt_xfer(0, _xd.ep_in, (uint8_t *)report, sizeof(xinput_report_t));
}
